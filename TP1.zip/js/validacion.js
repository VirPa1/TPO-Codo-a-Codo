var elementos = document.getElementsByClassName('elementos');
//console.log(elementos);
var alert = document.getElementById('alert');
alert.style.display = 'none';

function validar(){
    if(elementos != "" ){
        alert.style.display = 'block';
        alert.style.backgroundColor = 'red';
        alert.style.color = 'white';
        alert.style.fontWeight = 'bold';
        alert.style.padding = '1em';
        alert.style.marginBottom = '1em';
    }

}
